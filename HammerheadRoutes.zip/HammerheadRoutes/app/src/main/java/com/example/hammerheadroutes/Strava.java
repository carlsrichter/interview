package com.example.hammerheadroutes;

class Strava {

    String serviceName = "Strava";
    String[] stringArray = new String[] {"SRT", "CVT", "Perkiomen"};

}
