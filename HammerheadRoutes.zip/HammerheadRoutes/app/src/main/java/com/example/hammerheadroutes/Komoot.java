package com.example.hammerheadroutes;

class Komoot {

    String serviceName = "Komoot";
    String[] stringArray_Komoot = new String[] {"SRT", "Welsh Mountain", "Oaks to Philly"};

}
