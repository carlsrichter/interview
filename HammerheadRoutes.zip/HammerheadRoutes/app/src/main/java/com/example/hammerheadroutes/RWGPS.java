package com.example.hammerheadroutes;

class RWGPS {

    String serviceName = "RWGPS";
    String[] stringArray_RWGPS = new String[] {"CVT", "Perkiomen", "Welsh Mountain"};

}
