package com.example.hammerheadroutes;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.NumberPicker;
import android.widget.ProgressBar;
import android.widget.Switch;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Context mContext = MainActivity.this;
    private ListView listView_Routes;
    private EditText editText_UserId;
    private NumberPicker numberPicker_Routes;

    private String[] stringArray_AllRoutes;

    private ArrayAdapter<String> arrayAdpater_Routes;

    private ArrayList<String> arrayList_Routes;

    private LinearLayout linLayout_Switches;
    private Switch switch_Strava;
    private Switch switch_RWGPS;
    private Switch switch_Komoot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setupActivityWidgets();
    }

    private void setupActivityWidgets() {

        listView_Routes = findViewById(R.id.listView_Routes);
        editText_UserId = findViewById(R.id.editText_UserId);
        numberPicker_Routes = findViewById(R.id.numberPicker_Routes);

        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        editText_UserId.setSelection(editText_UserId.getText().length());
        editText_UserId.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if ((event.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER)) {
                    numberPicker_Routes.setValue(2);
                    userRoutes();
                    return true;
                }
                return false;
            }
        });

        editText_UserId.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                numberPicker_Routes.setValue(2);
                userRoutes();
            }
        });

        String[] numberPickerStringArray = new String[]{"All Routes", "Unique Routes", "User Routes", "User Routes by Service"};
        numberPicker_Routes.setMinValue(0);
        numberPicker_Routes.setMaxValue(numberPickerStringArray.length-1);
        numberPicker_Routes.setDisplayedValues(numberPickerStringArray);

        numberPicker_Routes.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal) {

                linLayout_Switches.setVisibility(View.GONE);

                switch (newVal) {
                    case 0:
                        allRoutes();
                        break;
                    case 1:
                        uniqueRoutes();
                        break;
                    case 2:
                        userRoutes();
                        break;
                    case 3:
                        linLayout_Switches.setVisibility(View.VISIBLE);
                        userRoutesByService();
                        break;
                }

            }
        });

        linLayout_Switches = findViewById(R.id.linLayout_Switches);
        linLayout_Switches.setVisibility(View.GONE);
        switch_Strava = findViewById(R.id.switch_Strava);
        switch_RWGPS = findViewById(R.id.switch_RWGPS);
        switch_Komoot = findViewById(R.id.switch_Komoot);

        switch_RWGPS.setChecked(true);
        switch_Komoot.setChecked(true);

        switch_Strava.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                userRoutesByService();
            }
        });

        switch_RWGPS.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                userRoutesByService();
            }
        });

        switch_Komoot.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                userRoutesByService();
            }
        });


        Strava strava = new Strava();
        RWGPS rwgps = new RWGPS();
        Komoot komoot = new Komoot();
        stringArray_AllRoutes = getStringArray_AllRoutes(strava.stringArray, rwgps.stringArray_RWGPS, komoot.stringArray_Komoot);

        uniqueRoutes();
        userRoutes();
        userRoutesByService();
        allRoutes();

    }

    private String[] getStringArray_AllRoutes(String[] stringArray_A, String[] stringArray_B, String[] stringArray_C) {

        List<String> list_AllRoutes = new ArrayList<>();
        Collections.addAll(list_AllRoutes,stringArray_A);
        Collections.addAll(list_AllRoutes,stringArray_B);
        Collections.addAll(list_AllRoutes,stringArray_C);
        String[] stringArray_AllRoutes = list_AllRoutes.toArray(new String[list_AllRoutes.size()]);

        return stringArray_AllRoutes;
    }


    private void allRoutes() {

        arrayList_Routes = new ArrayList<String>();
        arrayList_Routes.addAll(Arrays.asList(stringArray_AllRoutes));
        arrayAdpater_Routes = new ArrayAdapter_Routes(mContext, R.layout.list_item, arrayList_Routes);
        listView_Routes.setAdapter(arrayAdpater_Routes);

        System.out.println("All Routes: " + arrayList_Routes);

    }

    private void uniqueRoutes() {

        ArrayList<String> arrayList_UniqueRoutes = new ArrayList<String>();
        LinkedHashSet<String> linkedHashSet = new LinkedHashSet<String>();
        linkedHashSet.addAll(Arrays.asList(stringArray_AllRoutes));
        arrayList_UniqueRoutes.addAll(linkedHashSet);
        arrayAdpater_Routes = new ArrayAdapter_Routes(mContext, R.layout.list_item, arrayList_UniqueRoutes);
        listView_Routes.setAdapter(arrayAdpater_Routes);

        System.out.println("Unique Routes: " + arrayList_UniqueRoutes);

    }

    private void userRoutes() {

        Strava strava = new Strava();
        RWGPS rwgps = new RWGPS();
        Komoot komoot = new Komoot();

        String[] stringArray_StravaUserRoutes = getStravaUserRoutes(strava);
        String[] stringArray_RWGPSUserRoutes = getRWGPSUserRoutes(rwgps);
        String[] stringArray_KomootUserRoutes = getKomootUserRoutes(komoot);

        String[] stringArray_UserRoutes = getStringArray_AllRoutes(stringArray_StravaUserRoutes, stringArray_RWGPSUserRoutes, stringArray_KomootUserRoutes);

        arrayList_Routes = new ArrayList<String>();
        arrayList_Routes.addAll(Arrays.asList(stringArray_UserRoutes));
        arrayAdpater_Routes = new ArrayAdapter_Routes(mContext, R.layout.list_item, arrayList_Routes);
        listView_Routes.setAdapter(arrayAdpater_Routes);

        System.out.println("For User " + editText_UserId.getText().toString() + ": " + arrayList_Routes);

    }

    private void userRoutesByService() {

        Strava strava = new Strava();
        RWGPS rwgps = new RWGPS();
        Komoot komoot = new Komoot();

        List<String> list_Services = new ArrayList<>();

        List<String> list_UserRoutesByService = new ArrayList<>();

        if (switch_Strava.isChecked()) {

            list_Services.add(strava.serviceName);
            String[] stringArray_StravaUserRoutes = getStravaUserRoutes(strava);
            Collections.addAll(list_UserRoutesByService,stringArray_StravaUserRoutes);

        }

        if (switch_RWGPS.isChecked()) {

            list_Services.add(rwgps.serviceName);
            String[] stringArray_RWGPSUserRoutes = getRWGPSUserRoutes(rwgps);
            Collections.addAll(list_UserRoutesByService,stringArray_RWGPSUserRoutes);

        }

        if (switch_Komoot.isChecked()) {

            list_Services.add(komoot.serviceName);
            String[] stringArray_KomootUserRoutes = getKomootUserRoutes(komoot);
            Collections.addAll(list_UserRoutesByService,stringArray_KomootUserRoutes);

        }

        String[] stringArray_UserRoutesByService = list_UserRoutesByService.toArray(new String[list_UserRoutesByService.size()]);

        arrayList_Routes = new ArrayList<String>();
        arrayList_Routes.addAll(Arrays.asList(stringArray_UserRoutesByService));
        arrayAdpater_Routes = new ArrayAdapter_Routes(mContext, R.layout.list_item, arrayList_Routes);
        listView_Routes.setAdapter(arrayAdpater_Routes);

        System.out.println("For User " + editText_UserId.getText().toString() + " Services: " + list_Services + ": " + list_UserRoutesByService);

    }

    private String[] getStravaUserRoutes(Strava strava) {

        for (int i = 0; i < strava.stringArray.length; i++) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(editText_UserId.getText().toString());
            stringBuilder.append(strava.stringArray[i]);
            strava.stringArray[i] = stringBuilder.toString();
        }

        return strava.stringArray;
    }

    private String[] getRWGPSUserRoutes(RWGPS rwgps) {

        for (int i=0; i < rwgps.stringArray_RWGPS.length; i++) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(rwgps.stringArray_RWGPS[i]);
            stringBuilder.append(editText_UserId.getText().toString());
            rwgps.stringArray_RWGPS[i] = stringBuilder.toString();
        }

        return rwgps.stringArray_RWGPS;
    }

    private String[] getKomootUserRoutes(Komoot komoot) {

        for (int i=0; i < komoot.stringArray_Komoot.length; i++) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(editText_UserId.getText().toString());
            stringBuilder.append(komoot.stringArray_Komoot[i]);
            stringBuilder.append(editText_UserId.getText().toString());
            komoot.stringArray_Komoot[i] = stringBuilder.toString();
        }

        return komoot.stringArray_Komoot;
    }

}
