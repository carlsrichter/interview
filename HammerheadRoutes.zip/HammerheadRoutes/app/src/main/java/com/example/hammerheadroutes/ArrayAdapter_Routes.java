package com.example.hammerheadroutes;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ArrayAdapter_Routes extends ArrayAdapter<String> {

    private Context mContext;
    private LayoutInflater mInflater;
    private int mLayoutResource;
    private ArrayList<String> arrayList_Routes;

    public ArrayAdapter_Routes(Context mContext, int mLayoutResource, ArrayList<String> arrayList_Routes) {
        super(mContext, mLayoutResource, arrayList_Routes);

        this.mContext = mContext;
        this.mInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.mLayoutResource = mLayoutResource;
        this.arrayList_Routes = arrayList_Routes;

    }

    class ViewHolder{

        TextView textView_route;

    }

    @NonNull
    @Override
    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        final ViewHolder viewHolder;

        if (convertView == null) {

            convertView = mInflater.inflate(mLayoutResource, parent, false);
            viewHolder = new ViewHolder();

            viewHolder.textView_route = convertView.findViewById(R.id.textView_route);

            convertView.setTag(viewHolder);

        } else {

            viewHolder = (ViewHolder) convertView.getTag();

        }

        viewHolder.textView_route.setText(arrayList_Routes.get(position));

        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(mContext, String.valueOf(arrayList_Routes.get(position)) + " clicked", Toast.LENGTH_SHORT).show();
            }
        });

        return convertView;
    }

}